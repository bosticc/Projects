# Myles Bostic 9.11.19






#Initializing variables
yesString = "Yes"
noString = "No"
errorString = "I'm afraid you didn't enter the input correctly. Please refresh!"
compWins = "I win! Thanks for playing though!"
compLoses = "Aw shucks. I messed up. Refresh and try a different colony!"
# 5 questions game


#introduction
print("Hi! Welcome to the 5 questions game: 13 colonies  edition. In this game, you think of one of the 13  original colonies ")

print("that is now a state, and I try to guess it. If I can't guess it in 5 questions, you win. I will only ask you Yes or No quesitons. Let's go!")

print("Before you begin, please remember, you must type 'Yes' and 'No' exactly like this, or ")

print("you'll throw the computer in for a.... wait for it....  'loop'. *ba dum tiss* ")

#First question, asks if the state is 2 words or one
print("Is the state's name comprised of two words? (ex. North Dakota)")
twoWords = input(">> ")


#If the state has two words and was in the 13 colonies, it fits this
#criteria, and could be NH, NJ, NC, SC, RI, or NY

if(twoWords==yesString):
    print("Does the state's first word start with the letter N? (ex. Nevada) ")
    startsWithN = input(">> ")
    
    #Asks if the state shares a border with a state in 
    # New England
    if(startsWithN==yesString):
        print("Does your state share a border with a state in New England? (ex. Massachusetts and Conneticut) ")
        neBorder = input (">> ")
        
        #Asks if the state borders a Great Lake
        if(neBorder==yesString):
            print("Does your state border a great lake?")
            borderGL = input(">> ")
            
            #If the state borders the GL, it is NY. Print NY
            if(borderGL==yesString):
                print("Is your state New York?")
                stateNY = input(">> ")
                if(stateNY == yesString):
                    print(compWins)
            #If the state does not border the GL, it is NH.
            #Print NY.
            elif(borderGL == noString):
                print("Is your state New Hampshire?")
                stateNH = input(">> ")
                if(stateNH == yesString):
                    print(compWins)
                
        #Asks if the state ever seceded from the Union.
        if(neBorder == noString):
            print("Did your state ever secede from the Union?")
            seceded = input(">> ")
            
            #If the state seceded from the Union, it is North
            # Carolina. Print NC
            if(seceded == yesString):
                print("Is your state North Carolina?")
                stateNC = input(">> ")
                if(stateNC == yesString):
                    print(compWins)
                    
            #If the state didn't secede from the Union,
            # it is New Jersey. Print NJ
            if(seceded == noString):
                print("Is your state New Jersey?")
                stateNJ = input(">> ")
                if(stateNJ == yesString):
                    print(compWins)
                
        
    #Asks if the state is in New England
    if(startsWithN == noString):
        print("Is the state in New England? (ex. Conneticut) ")
        inNe = input(">> ")
        
        #If the state is in New England, it is Rhode Island. Print 
        #RI
        if(inNe == yesString):
            print("Is you state Rhode Island?")
            stateRI = input(">>")
            if(stateRI == yesString):
                print(compWins)
        
        #If the state is not in New England, it is SC.
        # Print SC
        elif(inNe == noString ):
            print("Is your state South Carolina?")
            stateSC = input(">> ")
            if(stateSC == yesString):
                print(compWins)
        
            
            
#If the state does not have two words and was in the 13 colonies
# it could be MA, CT, MD, PA, DE, VA, GA.
#
#Now we ask if the state end in a vowel 
elif(twoWords == noString):
    print("Does your state end in a vowel? (ex. California)")
    endInaVowel = input(">> ")
    
    #If the state ends in a vowel, we ask if the state 
    #was named after a king or queen
    if(endInaVowel == yesString):
        print("Was your state named after a king/queen? (ex. North Carolina, South Carolina, Louisiana, Georgia, Virginia, Maryland) ")
        royalState = input(">> ")
        
        #If the state was named after someone of majesty,
        #we ask if the Olympics were ever hosted
        # in their state
        if(royalState == yesString):
            print("Has your state ever hosted The Olympics? (ex. California hosted the 1932 & 1984 Olympics in Los Angeles)")
            olympicState = input(">> ")
            
            #If the olympics have been hosten in the state, then the state is Georgia. Print Georgia.
            if(olympicState == yesString):
                print("Is your state Georgia?")
                stateGA = input(">> ")
                if(stateGA == yesString):
                    print(compWins)
                
                    
            #If the state olympics haven't been hosted in the state,
            # it is Virginia. Print Virginia
            if(olympicState == noString):
                print("Is your state Virginia?")
                stateVA = input(">> ")
                if(stateVA == yesString):
                    print(compWins)
        
        #If the state was not named after someone of majesty, we ask
        #if the state borders the Atlantic Ocean
        if(royalState == noString):
            print("Does your state border the Atlantic Ocean?")
            borderAO = input(">> ")
            
            #If the state border the Atlantic Ocean, we ask if the state
            # is Deleware. Print Deleware
            if(borderAO == yesString):
                print("Is your state Deleware?")
                stateDE = input(">> ")
                if(stateDE == yesString):
                    print(compWins)
        
            #If the state does not border the Atlantic Ocean, then it 
            #is Pennsylvania. Print Pennsylvania.
            if(borderAO == noString):
                print("Is your state Pensylvania?")
                statePA = input(">> ")
                if(statePA == yesString):
                    print(compWins)
                else:
                    print(compWins)
                    
                    
    #If the state does not end in a vowel, we ask if the 
    #state home to an ivy league school
    elif(endInaVowel == noString):
        print("Is your state home to an Ivy League University/College?")
        ilState = input(">> ")
        
        #If the state is home to an ivy league school, we ask if the state
        # is home to the NBHOF
        
        if(ilState == yesString):
            print("Is your state home to the National Basketball Hall of Fame?")
            hofState = input(">> ")
            
            # If the state has the NBHOF, 
            # it is MA. print Massachusetts. 
            if(hofState == yesString):
                print("Is your state Massachusetts?")
                stateMA = input(">> ")
                if(stateMA == yesString):
                    print(compWins)
            
            # If the state does not have the NBHOF, it Is
            #Conneticut. Print Conneticut
            elif(hofState == noString):
                print("Is your state Conneticut?")
                stateCT = input(">> ")
                if(stateCT == yesString):
                    print(compWins)
        
        #If the state is made up of one word and the state does not 
        # have an Ivy League school, it is Maryland. Print Maryland.
        if(ilState == noString):
            print("Is your state Maryland?")
            stateMD = input(">> ")
            if(stateMD == yesString):
                print(compWins)
else:
    print(errorString)