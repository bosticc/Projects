
# Your code here!
print("Please insert your first number")

firstNum = int(input(">> "))

print("Please insert your second number")

secondNum = int(input(">> "))

print("Your numbers are " + str(firstNum) + " and " + str(secondNum))

print("Select your operator: ADD, MULTIPLY or SUBTRACT")

operator = input(">> ")

if(operator == "ADD"):
    print( "Your result is " + str(firstNum + secondNum))
elif(operator == "SUBTRACT"):
    print(" Your result is " + str(firstNum - secondNum))
elif(operator == "MULTIPLY"):
    print(" Your result is " + str(firstNum * secondNum))
else:
    print(" Sorry, that option is not supported")

    