# Mad Lib game!
print("Please input a noun")
noun = input(" >>")

print("Please input a adjective")
adjective = input(" >>")

print("Please input a verb")
verb = input(" >>")

print("Please input a name")
name = input(" >>")

print("This morning, " + name + " felt like eating tacos for breakfast. " + name + " loves to eat tacos, but only after they " + verb + " in the morning .So, they went to the ice cream shop, and asked for about 7 tacos. They didn't have any cash on them because they feel as though paper money contributes to Global Warming. So instead, they pulled out a " + noun + " and began to barter with the cashier. The cashier looked suprised. He pulled out a " + adjective + " taco, and told " + name + " to have a nice day. The End." )




