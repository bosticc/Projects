#include <iostream>
using namespace std;
#include <string>
#include <iomanip>
#include <ostream>
#include <fstream>
ifstream myfile;
int questions = 0;
int errors = 0;
bool isHung(int);
string answer, theAnswer;



int main() {
  myfile.open("infile.txt");
  string question, opa, opb, opc, opd, user_guess, answer;
  cout << "welcome to hangman" << endl;
  while(questions < 16)
  {
    getline(myfile,question);
    getline(myfile,opa);
    getline(myfile,opb);
    getline(myfile,opc);
    getline(myfile,opd);
    getline(myfile,answer);
    theAnswer = answer.substr(16,17);
    // Print out every question.

    cout << question << endl << opa << endl << opb << endl << opc << endl << opd << endl << "Please answer:";
    cin >> user_guess;
    // Handle user input. If the user has too many errors,
    // break and end the game

    if(user_guess != theAnswer)
    {
      errors++;
      cout << endl <<" Wrong!" << endl << "YOU HAVE: " << errors << " WRONG GUESS(ES)";
      if(isHung(errors))
      {
        break;
      }
    }
    else
    {
      cout << "You got it right! Congrats!" << endl;
    }
    questions++;
    cout << endl << "******************************" << endl;
  }
  cout << "CONGRATS! YOU BEAT THE GAME!!" << endl;
}
bool isHung(int numErrors)
{
  // Switch for the # of errors that the user has accrued 
  // so far.
  switch (numErrors)
  {
    case 1:
    cout << endl << "\t\t\t" << "0" << endl;
    break;
    case 2:
    cout << endl << "\t\t\t" << "0" << endl
                 << "\t\t\t" << "|" << endl;
    break;
    case 3:
    cout << endl << "\t\t\t" << "0" << endl
                 << "\t\t   " <<  "/|" << endl;
    break;
    case 4:
    cout << endl << "\t\t\t" << "0" << endl
                 << "\t\t   " <<  "/|\\" << endl;
    break;
    case 5:
    cout << endl << "\t\t\t" << "0" << endl
                 << "\t\t   " <<  "/|\\" << endl << 
                    "\t\t\t" << "| " <<
                 endl;
    break;
    case 6:
    cout << endl << "\t\t\t" << "0" << endl
                 << "\t\t   " <<  "/|\\" << endl << 
                    "\t\t\t" << "| " << endl <<
                    "\t\t   " <<  "/|"<< endl;
    break;
    case 7:
    cout << endl << "\t\t\t" << "0" << endl
                 << "\t\t   " <<  "/|\\" << endl << 
                    "\t\t\t" << "| " << endl <<
                    "\t\t   " << "/|\\"<< endl;
                    cout << "YOU LOSE, THANKS FOR PLAYING" << endl;
    break;
  }
  if( numErrors == 7)
  {
    return true;
  }
  return false;
}