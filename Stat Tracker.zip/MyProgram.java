/*
*
*
*Myles Bostic April 2nd 2019. This code runs
*but has not been commented out. Apologies
/but has not been commented out. Apologies

public class MyProgram extends ConsoleProgram
{
     String name1 = "";
     String college1 = "";
     String nationality1 = "";
     int age1 = 0;
     double ppg1 = 0;
     double apg1 = 0;
     double rpg1 = 0;
     int whatIsNext = 0;
     boolean startTeam = false;
     boolean teamMade = false;
     Team team1 = new Team();
     Player hooper1 = new Player(" ");
     Player hooper2 = new Player("");
     int counter = 0;
     boolean noMore = false;
     boolean firstTime = true;
     
     
    public void run()
    {
        
        System.out.println("Hi, welcome to Myles' Basketball Player Profile Calculator \n" );
        
        System.out.println("I can track stats for you, compare players and \n" + " compare teams. Let's make your first player!");
        
        
        makePlayer(hooper1);
        team1.addPlayer(hooper1);
        
        //While loop that let's you keep doing whatever you want as long as you
        // you don't hit negative 1
        
        
        while(whatIsNext != -1)
        {
        if(firstTime ==true)
        {
            System.out.println("Congrats! You have made your first player. Here is a rundown on them \n"  + hooper1.toString());
            firstTime =false;
        }
        System.out.println("You can:");
        System.out.println("Keep doing players (hit 1) \n" + "or quit (type -1)");
        if(startTeam == true)
        {
            System.out.println("You can also start to make a team. \n" + "Would you like to do that? \n"  + "Type 2 if you would like to \n");
            if(noMore ==false)
            {
                System.out.println("Or you can compare the two players you have now. \n" + "Hit 5 if so.");

            }
        }
        
        if(teamMade == true)
        {
            //Just make this print all the players out. If u have time make it sort em.
            System.out.println("I can now sort the players by points per game, \n" + "if you'd like. Type 3 if you want me to.");
        }
        
        
        
        whatIsNext = readInt("What would you like to do?");
        
        
        
        
        
        
        
        
        //Post menu
        
        
        
        
        //make another player
        if(whatIsNext == 1)
        {
            System.out.println("Let's make your second player");
            makePlayer(hooper2);
            team1.addPlayer(hooper2);
            startTeam = true;
        }
        
        
        //Make a team
        if(whatIsNext == 2)
        {
            
            
           System.out.println(" Ok, you have decided you would like to make a team.");
           
           
           
           System.out.println(" Since you have already made 1 player, \n" + " all we need to make is 4 more");
           
           
           
           makePlayer(hooper2);
           team1.addPlayer(hooper2);
           
           Player hooper3 = new Player("");
           makePlayer(hooper3);
           team1.addPlayer(hooper3);
           
           
           
           
           Player hooper4 = new Player("");
           makePlayer(hooper4);
           team1.addPlayer(hooper4);
           
           
           Player hooper5 = new Player("");
           makePlayer(hooper5);
           team1.addPlayer(hooper5);
           System.out.println(team1.toString());

           
           whatIsNext = -1;
           teamMade = true;
           
           
           
        }
        
        //sort daTeam
        
        if(whatIsNext == 5 && noMore ==false)
        {
            System.out.println(hooper1.compareStats(hooper2));
            noMore =true;
        }
        
        
        } 
    
        
        System.out.println("Thanks for using me! Come back soon.");
    
    }
    /**
     * This method makes a player
     * @param is the player object being created
     */
    
    private void makePlayer(Player instance)
    {
        String name1 = "";
        String college1 = "";
        String nationality1 = "";
        int age1 = 0;
        double ppg1 = 0;
        double apg1 = 0;
        double rpg1 = 0;
       // Player hooper = new Player(" ", " ", " ", 0, 0, 0, 0);
        name1 = readLine("what is your players name? ");
        college1 = readLine(name1 + " is a cool name. \n" + "where did they go to college? (Include ____ university/college)  ");
        if(counter == 0)
        {
            nationality1 = readLine(college1 + " is where my aunt went! \n" + "gosh it is a small world out here. \n" + " where are they from? ");
        }
        else
        {
            nationality1 = readLine(college1 + " is where my OTHER aunt went! \n" + "gosh it is a small world out here. \n" + " where are they from? ");
        }
        age1 = readInt("How old are they?");
        
       // System.out.println("Now I will ask you some questions about their averages\n" + "Specifically, their points, rebounds and assists per game \n" + "Would you like to calculate an average?");
        //boolean needAnAverage = readBoolean("true for yes or false if no: ");
        //while(needAnAverage == true)
        //{
        //    System.out.println("The average that has been calculated is: " + calcAverage());
        //    needAnAverage = readBoolean("Type true if you'd like to find \n" + " another average or false if you are done");
       // }
        apg1 = readDouble("How many assists per game did they have? ");
        ppg1 = readDouble("How many points per game did they game? ");
        rpg1 = readDouble("How many rebounds per game did they have? ");
        
        instance.setName(name1);
        instance.setCollege(college1);
        instance.setNationality(nationality1);
        instance.setAge(age1);
        instance.setPpg(ppg1);
        instance.setApg(apg1);
        instance.setRpg(rpg1);
        counter++;
    }
    
    
    
    /**
     * This method calculates the average of a set of numbers
     * @return the average calculated
     * 
     * NOT USED*******
     */
    public double calcAverage()
    {
        boolean stillGoing = true;
        double runningAverage = 0;
        double average = 0;
        double counter = 0;
        System.out.println("Hi");
        boolean yo = true;
        stillGoing = true;
        if(yo == true);
        {
            runningAverage = readDouble("Enter a value, type -1 if you're done entering values");
            if(runningAverage == -1)
            {
                yo = false;
                counter--;
            }
            average += runningAverage;
            counter++;
            
        }
        
        return average / counter;
    }
    
    
    
}