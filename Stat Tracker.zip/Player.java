public class Player implements Comparable<Player>
{
    private String name;
    private String college;
    private String nationality;
    private int age;
    private double ppg;
    private double apg;
    private double rpg;
    
    public Player(String name, String college, String nationality, int age, double apg, double ppg, double rpg)
    {
        this.name = name;
        this.college = college;
        this.nationality = nationality;
        this.age = age;
        this.ppg = ppg;
        this.apg = apg;
        this.rpg = rpg;
        
    }
    
    public Player(String name)
    {
        this.name = "Everything about this player will be initialized later.";
    }
    
    
    /**
     * This method allows you to compare two players
     * @return age of the player. 
     * 
     * 
     * 
     * To be honest, i dont know why this is in my code, but
     * when I take it out it throws a hissy fit.
     * I got this from CodeHs
     * 
     */
    public int compareTo(Player other)
    {
        return age;
    }
    
    
    
    /**
     * This method returns a string of  players
     * @return comparison string of the two players
     * @param is the other players
     */
     
     public String toString()
     {
        return  "\n" + "\n" + "You have made a " + getAge() + " year old player named " + getName() + " from \n" + getNationality()  + " They went to school at the illustrious " + getCollege() + " \n"  + " Currently," + "They are averaging " + getRpg() + " " + getPpg() + " " + getApg()+ " " + "\n" + "rebounds, points and assists per game respectively \n" + "This is just astronomical."; 
     }
    
    
    /**
     * This method compares two players
     * @return comparison string of the two players
     * @param is the other players
     */
    public String compareStats(Player other)
    {
        double oApg = other.getApg();
        double oPpg = other.getPpg();
        double oRpg = other.getRpg();
        boolean greaterOtherApg = false;
        boolean greaterOtherPpg = false;
        boolean greaterOtherRpg = false;
        
        
        
        
        //just giving some values to some booleans so that I can make a
        //accurate return string
        if(oApg > apg)
        {
            greaterOtherApg = true;
        }
        
        if(oPpg > ppg)
        {
            greaterOtherPpg = true;
        }
        
        if(oRpg > rpg)
        {
            greaterOtherRpg = true;
        }
        
        
        //Other had better everything
        if(greaterOtherApg == true && greaterOtherPpg == true && greaterOtherRpg ==true)
        {
            return "Wow, it's pretty clear that " + other.getName() + "has really been working on their game while" + getName() + "has not. /n" + "tell your player to get in the gym chief"; 
        }
        
        //Self had better everything
        if(greaterOtherApg == false && greaterOtherPpg == false && greaterOtherRpg ==false)
        {
            return "Wow, it's pretty clear that \n" + getName() + "has really been working on their game while \n" + other.getName() + " this is just attrocious \n" + getName() + " is just better in every way possible!"; 
        }
        
        
        return "Did " + other.getName() + " have a better assists per game average? \n" + greaterOtherApg + " \n"  + " Did" + other.getName() + "  have a better points per game average? \n" + greaterOtherPpg+ " \n"  + " Did " + other.getName() + "  have a better rebounds per game average? \n" + greaterOtherRpg;
        
        
        
    }
    

    
    
    //getters
    
    /**
     * This method returns the name
     * @return string of the name
     * 
     */
     
    public String getName()
    {
        return name;
    }
    
    /**
     * This method returns the college the player attended
     * @return string of the college
     * 
     */
    public String getCollege()
    {
        return college;
    }
    
    
    /**
     * This method returns the nationality
     * @return string of the nationality
     * 
     */
    public String getNationality()
    {
        return nationality;
    }
    
    /**
     * This method returns the age
     * @return age of the player
     * 
     */
    
    public int getAge()
    {
        return age;
    }
    
    /**
     * This method returns the player's average points per game'
     * @return  the player's points per game value
     * 
     */
    
    public double getPpg()
    {
        return ppg;
    }
    
    /**
     * This method returns the player's average assists per game
     * @return  the player's assists per game value
     * 
     */
    
    public double getApg()
    {
        return apg;
    }
    
    /**
     * This method returns the player's average rebounds per game
     * @return  the player's rebounds per game value
     * 
     */
    
    public double getRpg()
    {
        return rpg;
    }
    
    
    
    
    //setters
    
    /**
     * This method sets the name
     * @param string of the new name
     * 
     */
    
    public void setName(String newName)
    {
        name = newName;
    }
    
    /**
     * This method sets the college the player attended
     * @param string of the college
     * 
     */
    
    public void setCollege(String newCollege)
    {
        college = newCollege;
    }
    
    /**
     * This method sets the nationality of the 
     * @param string of the nationality of the player
     * 
     */
     
    public void setNationality(String newNationality)
    {
        nationality = newNationality;
    }
    
    
    /**
     * This method sets the age of the player
     * @param int of the new age of the player
     * 
     */
     
     
    
    public void setAge(int newAge)
    {
        age = newAge;
    }
    
    /**
     * This method sets the Points per game of the player
     * @param the new points per player of the game
     * 
     */
    
    public void setPpg(double newPpg)
    {
        ppg = newPpg;
    }
    
    
    /**
     * This method sets the assists per game of the player
     * @param the new assists per game of the player
     */
     
     
    public void setApg(double newApg)
    {
        apg = newApg;
    }
    
    
    /**
     * This method sets the assists per game of the player
     * @param the new assists per game of the player
     */
    public void setRpg(double newRpg)
    {
        rpg = newRpg;
    }
    
    
    

}
