import java.util.ArrayList;

public class Team
{
    double biggestNum = 0;
    private ArrayList <Player> daTeam;
    
    
    public Team()
    {
        daTeam = new ArrayList<Player>();
    }
    
    /**
     * Adds the player to the team, adding the elements of the hooper
     * and then making a hooper object
     * @param name of player
     * @param nationality of player
     * @param college of player
     * @param age of player
     * @param apg of player
     * @param rpg of player
     * @param ppg of player
     */
    public void addPlayer(String name, String nationality, String college, int age, double apg, double ppg, double rpg)
    {
        Player hooper1 = new Player(name, college, nationality, age, apg, ppg, rpg );
        
        daTeam.add(hooper1);
    }
    
    /**
     * Adds the player to the team, adding the actual hooper itself
     * @param the player.
     */
    
    public void addPlayer(Player hooper)
    {
        daTeam.add(hooper);
    }
    
    /**
     * Returns a summary of the team.
     * @return the summary.
     */
    
    public String toString()
    {
        String names = " ";
        for(int i = 0; i < daTeam.size(); i++)
        {
            names += daTeam.get(i).toString();
        }
        
        return names;
        
    }
    
    
}
