//Myles Bostic, 5.4.17. 

// This program draws a target that follows the mouse

//Initializes variables
var line;
var line2;
var circle;
function start(){
	mouseMoveMethod(target);
	mouseClickMethod(ballz);
}


/*This function makes two new lines and colors, while
* removing the other two
*/

function target(e){
    remove(line);
    remove(line2);
    line = new Line(e.getX(), 0, e.getX(),getHeight());
    line.setColor(Randomizer.nextColor());
    add(line);
    line2 = new Line(0, e.getY(), getWidth(), e.getY());
    line2.setColor(Randomizer.nextColor());
    add(line2);
}

/*
*This function removes the old circle while also making
* a new one each time the mouse is moved.
*/

function ballz(e){
    remove(circle);
    circle = new Circle(50 -25);
    circle.setPosition(e.getX(), e.getY());
    circle.setColor(Randomizer.nextColor());
    add(circle);
}